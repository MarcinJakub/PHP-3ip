<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T13NNN - punkt prostokąt</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header>
        <h1>T13NNN - punkt prostokąt</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz klasę Punkt przechowującą współrzędne x i y  punktu (wszystkie pola publiczne – choć wiemy, że to nie jest najlepsze rozwiązanie ;) ). Napisz kod przykładowej klasy Prostokat zawierającej cztery pola przechowujące współrzędne czterech rogów prostokąta. Wykorzystaj obiekty klasy Punkt. Zastosuj klasę Prostokat w programie.</p>
    </header>
        <?php
        class Punkt{
            public $x, $y;
        }
        class Prostokat{
            public $lewyGorny, $prawyGorny, $prawyDolny, $lewyDolny;
        }

        $p1 = new Punkt();
        $p2 = new Punkt();
        $p3 = new Punkt();
        $p4 = new Punkt();

        $p1->x = 3;
        $p1->y = 3;

        $p2->x = 6;
        $p2->y = 3;

        $p3->x = 6;
        $p3->y = 1;

        $p4->x = 3;
        $p4->y = 1;

        $prostokat = new Prostokat();

        $prostokat->lewyGorny = $p1;
        $prostokat->prawyGorny = $p2;
        $prostokat->prawyDolny = $p3;
        $prostokat->lewyDolny = $p4;
        ?>
</body>
</html>