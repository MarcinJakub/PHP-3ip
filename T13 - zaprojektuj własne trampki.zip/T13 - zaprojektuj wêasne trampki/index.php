<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T13 - zaprojektuj własne trampki</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Formularz konkursu "Podrasuj swoje buty!"</h1>
        <p>Chcesz zamienić swoje stare trampki na nową parę zaprojektowanych przez siebie butów Forcefield? Napisz nam, dlaczego sądzisz, że powinieneś <em>pożegnać się</em> ze swoimi wysłużonymi butami, a być może zostaniesz jednym z laureatów konkursu!</p>
    </header>
    <section>
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
            <div>
                <label for="imieNazwisko">Imię i nazwisko: </label><input type="text" id="imieNazwisko" name="imieNazwisko"><br>
                <label for="email">E-mail: </label><input type="text" id="email" name="email"/><br>
                <label for="telefon">Telefon: </label><input type="text" id="telefon" name="telefon"/><br>
                <label for="tekst">Moje buty są TAKIE stare...</label><br>
                <textarea id="tekst" name="tekst" maxlength="300" ></textarea>
            </div>
            <h2>Zaprojektuj własne trampki: </h2>
            <div>
                <div>
                    <input type="radio" id="kolor" name="kolor" value="red"><label for="kolor">czerwony</label><br>
                    <input type="radio" id="kolor" name="kolor" value="blue"><label for="kolor">niebieski</label><br>
                    <input type="radio" id="kolor" name="kolor" value="black"><label for="kolor">czarny</label><br>
                    <input type="radio" id="kolor" name="kolor" value="silver"><label for="kolor">srebrny</label><br>
                </div>
                <div>
                    <input type="checkbox" id="sznurowki" name="sznurowki"><label for="sznurowki">Błyszczące sznurówki</label><br>
                    <input type="checkbox" id="logo" name="logo"><label for="logo">Metalowe logo</label><br>
                    <input type="checkbox" id="podeszwy" name="podeszwy"><label for="podeszwy">Świecące podeszwy</label><br>
                    <input type="checkbox" id="mp3" name="mp3"><label for="mp3">Odtwarzanie MP3</label>
                </div>
                <div>
                    <label for="rozmiar">Rozmiar zgodny ze standardowymi numerami butów: </label><select id="rozmiar" name="rozmiar">
                        <option>37</option>
                        <option>38</option>
                        <option>39</option>
                        <option>40</option>
                        <option>41</option>
                        <option>42</option>
                        <option>43</option>
                        <option>44</option>
                        <option>45</option>
                        <option>46</option>
                        <option>47</option>
                    </select>
                </div>
            </div>
            <input type="submit" value="Podrasuj swoje buty!"/>
            <input type="reset" value="Resetuj"/>
        </form>
    </section>
</body>
</html>