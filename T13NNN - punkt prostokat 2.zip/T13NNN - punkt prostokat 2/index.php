<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T13NNN - punkt prostokąt 2</title>
</head>
<body>
<header>
    <h1>T13NNN - punkt prostokąt 2</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>Do utworzonej w ćwiczeniu 2 klasy Prostokat dopisz metody zwracające współrzędne wszystkich czterech punktów oraz metodę wyświetlającą wartość współrzędnych. Tym razem w klasie Punkt powinny wystąpić prywatne pola x i y. Dostęp do prywatnych pól realizujemy przez publiczne metody.</p>
</header>
<section>
    <?php
    class Punkt{
        private $x, $y;

        public function pobierzDane($a, $b){
            $this->x = $a;
            $this->y = $b;
        }

        function zwrocX(){
            return $this->x;
        }

        function zwrocY(){
            return $this->y;
        }
    }
    class Prostokat{
        public $lewyGorny, $prawyGorny, $prawyDolny, $lewyDolny;


    }

    $p1 = new Punkt();
    $p2 = new Punkt();
    $p3 = new Punkt();
    $p4 = new Punkt();

    $p1->pobierzDane(3,3);
    $p2->pobierzDane(6,3);
    $p3->pobierzDane(6,1);
    $p4->pobierzDane(3,1);

    $prostokat = new Prostokat();

    $prostokat->lewyGorny = $p1;
    $prostokat->prawyGorny = $p2;
    $prostokat->prawyDolny = $p3;
    $prostokat->lewyDolny = $p4;
    ?>
</section>
</body>
</html>