<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T09g - rozwinięcie kodu</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T09g - rozwinięcie kodu</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>
    Dana jest następująca tablica:<br><br>

    $players = [];<br>
    $players[] = ["Nazwisko" => "Ronaldo", "Wiek" => 31, "Kraj" => "Portugalia","Drużyna" => "Real Madrid"];<br>
    $players[] = ["Nazwisko" => "Messi", "Wiek" => 27, "Kraj" => "Argentyna", "Drużyna"=> "Barcelona"];<br>
    $players[] = ["Nazwisko" => "Neymar", "Wiek" => 24, "Kraj" => "Brazylia", "Drużyna"=> "Barcelona"];<br>
    $players[] = ["Nazwisko" => "Rooney", "Wiek" => 30, "Kraj" => "Anglia", "Drużyna"=> "Man United"];<br><br>

    Dopisz kod, który wyświetli tablicę wraz z nazwami kluczy.
    </p>
</header>
<section>
    <?php
    $players = [];
    $players[] = ["Nazwisko" => "Ronaldo", "Wiek" => 31, "Kraj" => "Portugalia","Drużyna" => "Real Madrid"];
    $players[] = ["Nazwisko" => "Messi", "Wiek" => 27, "Kraj" => "Argentyna", "Drużyna"=> "Barcelona"];
    $players[] = ["Nazwisko" => "Neymar", "Wiek" => 24, "Kraj" => "Brazylia", "Drużyna"=> "Barcelona"];
    $players[] = ["Nazwisko" => "Rooney", "Wiek" => 30, "Kraj" => "Anglia", "Drużyna"=> "Man United"];

    foreach ($players as $index => $infoZawodnika){
        echo "Informacje o zawodniku nr ".($index+1)."\n";
        foreach ($infoZawodnika as $klucz => $value){
            echo $klucz.": ".$value."\n";
        }
        echo "<br>";
    }
    ?>
</section>
</body>
</html>