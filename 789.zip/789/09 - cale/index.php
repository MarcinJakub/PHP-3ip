<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie 07 - temperatura</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
    <h1>Zadanie 09 - cale</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>Napisz program, który zamienia długość podaną w calach na mm.
        (1cal=25,3995 mm)</p>
</header>
<section>
    <form method="post">
        <label for="cale">Podaj długość w calach: </label><br>
        <input type="text" id="cale" name="cale"><br><br>
        <input type="submit" value="Wyślij" />
    </form><br><br>
    <?php
    if(isset($_POST['cale']) && is_numeric($_POST['cale'])) {
        $cale = $_POST['cale'];
        $milimetry = $cale * 25.3995;
        echo "$cale cali to $milimetry mm.";
    }
    ?>
</section>
</body>
</html>