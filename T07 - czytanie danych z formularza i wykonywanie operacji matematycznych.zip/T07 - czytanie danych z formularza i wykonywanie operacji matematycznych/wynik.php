<style>
    body{
        background-color: darkslateblue;
        color: darkblue;
        font-family: Arial;
    }
    header{
        background-color: white;
        border-radius: 10px;
        padding: 15px;
        margin: 20px;
    }

    section{
        background-color: white;
        border-radius: 10px;
        padding: 15px;
        margin: 20px;
        text-align: center;
        font-size: 16px;
    }
</style>

<?php
$imie = $_POST['imie'];

$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];

$tab = array($a, $b, $c, $d);

echo "<header><h1>Witaj <b>$imie</b> na mojej stronie!!!</h1></header><section>";

var_dump($tab);
echo "<br>";

$tab2 = array();
$n = 0;

for($i = 0; $i < sizeof($tab); $i++){
    //sprawdzanie, czy łańcuch znaków zawiera cyfrę
    for($j = 0; $j < strlen($tab[$i]); $j++){
        if(is_numeric($tab[$i][$j])){
            $tab[$i] = (float)$tab[$i];
            break;
        }
    }

    if(is_float($tab[$i])){
        $tab2[$n] = $tab[$i];
        ++$n;
    }
}

var_dump($tab2);
echo "<br><br>";

$suma = 0;

echo "Liczby:";
for($i = 0; $i < sizeof($tab2); $i++){
    echo " | $tab2[$i]";
    $suma += $tab2[$i];
}

echo " |<br><br>";
echo "Suma: $suma <br>";

$srednia = $suma/sizeof($tab2);

echo "Średnia: $srednia </section>";

?>