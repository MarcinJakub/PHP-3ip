<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T09c - tablica dwuwymiarowa znaków</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T09c - tablica dwuwymiarowa znaków</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz program, który do dwuwymiarowej tablicy o wymiarach 7 x 7 wpisze wygenerowane losowo znaki w zakresie <'a','e'>, wyświetli tę tablicę, a następnie:

            <ul>
                <li>wypisze ile razy w tablicy wystąpiła litera 'a',</li>
                <li>wyświetli te numery wierszy, w których najczęściej wystąpiła litera 'b'.</li>
            </ul>
            </p>
    </header>
    <section>
        <?php
            $array = array();

        for($i = 0; $i < 3; $i++){
            $array[$i] = [];
            for($j = 0; $j < 3; $j++){
                $rand = rand(0,4);
                switch($rand){
                    case 0:
                        $rand = "a";
                        break;
                    case 1:
                        $rand = "b";
                        break;
                    case 2:
                        $rand = "c";
                        break;
                    case 3:
                        $rand = "d";
                        break;
                    case 4:
                        $rand = "e";
                }
                $array[$i][$j] = $rand;
            }
        }

        $ileA = 0;
        $maxB = 0;

        $wierszeB = array();

        for($i = 0; $i < 3; $i++){
            $ileB = 0;
            echo "$i: ";
            for($j = 0; $j < 3; $j++){
                if($array[$i][$j] == "a"){
                    $ileA++;
                }

                if($array[$i][$j] == "b"){
                    $ileB++;
                    if($ileB == $maxB && $maxB > 0){
                        array_push($wierszeB, $i);
                    }
                    if($ileB > $maxB){
                        unset($wierszeB);
                        $wierszeB = array();
                        $maxB = $ileB;
                        array_push($wierszeB, $i);
                    }
                }
                echo $array[$i][$j];
                echo " ";
            }
            echo "<br>";
        }

        echo "<br>Litera 'a' wystąpiła w tablicy: $ileA razy<br>";
        echo "Litera B wystąpiła najczęściej w wierszach: ";

        if(empty($wierszeB)){
            echo "nie wystepuje";
        } else{
            for($i = 0; $i < sizeof($wierszeB); $i++){
                echo "$wierszeB[$i] ";
            }
        }

        ?>
    </section>
</body>
</html>