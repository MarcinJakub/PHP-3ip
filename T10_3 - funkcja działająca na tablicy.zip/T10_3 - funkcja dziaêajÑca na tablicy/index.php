<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T10_3 - funkcja działająca na tablicy</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T10_3 - funkcja działająca na tablicy</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Dana jest tablica tab zawierająca liczby oraz liczba m o określonej wartości.<br><br>

            Napisz funkcję, która
        <ul>
            <li>wyświetli tablicę w formie tabeli HTML,</li>
            <li>przemnoży wszystkie elementy tablicy tab przez czynnik m.</li>
            <li>zamieni wszystkie elementy w tablicy równe 0 na 1.</li>
        </ul>
        Zademonstruj działanie funkcji w programie.
        </p>
    </header>
    <section>
        <p>Dana jest tablica: {1,0,3,8,6,4,0,25,34}</p>
        <form action = "<?php echo $_SERVER['PHP_SELF']?>" method="post">
            <label for="m">Podaj m: </label><input type="text" id="m" name="m"/>
            <input type="submit" value="Wyślij" />
        </form>
        <?php
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            if(isset($_POST['m']) && is_numeric($_POST['m'])){
                function wyswietl(&$tab){
                    echo "<br><table><tr>";
                    foreach($tab as $x){
                        echo "<td>$x</td>";
                    }
                    echo "</tr></table><br><br>";
                }

                function przemnozPrzezM(&$tab, $m){
                    for($i = 0; $i < sizeof($tab); $i++){
                        $tab[$i] *= $m;
                    }
                }

                function zamienZeroNaJeden(&$tab){
                    for($i = 0; $i < sizeof($tab); $i++){
                        if($tab[$i] == 0){
                            $tab[$i] = 1;
                        }
                    }
                }

                $tab = array(1,0,3,8,6,4,0,25,34);
                $m = $_POST['m'];
                wyswietl($tab);
                echo "<p>Tablica po przemnożeniu przez czynnik <strong>m</strong>:</p><br>";
                przemnozPrzezM($tab, $m);
                wyswietl($tab);
                echo "<p>Tablica po zamienieniu elementów równych 0 na 1:</p><br>";
                zamienZeroNaJeden($tab);
                wyswietl($tab);
            }
        }
        ?>
    </section>
</body>
</html>