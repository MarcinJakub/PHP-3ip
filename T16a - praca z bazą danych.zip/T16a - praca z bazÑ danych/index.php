<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T16a - praca z bazą danych</title>
    <link rel="stylesheet" href="styl.css"/>
</head>
<body>
    <header>
        <h1>T16a - praca z bazą danych</h1>
        <h2>Autor: Marcin Panter</h2>
        <p>Tym razem zadanie jest bardziej złożone. Oto co należy zrobić:</p>
        <ul>
            <li>Utwórz bazę danych o nazwie 3ip_2_baza_pracownikow.</li>
            <li>Do zadania dołączony został plik zawierający dane 114 pracowników - dokonaj konwersji tych danych do formaty txt (uzyskaj plik z danymi pracownicy.txt.</li>
            <li>Na utworzonej stronie projektu znajduje się przycisk "Utwórz tabelę", który w bazie 3pir_2_baza_pracownikow tworzy tabelę pracownicy.</li>
            <li>Drugi przycisk "Załaduj dane" dodaje dane z pliku tekstowego pracownicy.txt do tabeli pracownicy.</li>
            <li>Trzeci przycisk wyświetla dane z tabeli pracownicy w postaci tabelarycznej.</li>
        </ul>
    </header>
    <section>
        <button>Utwórz tabelę</button>
        <?php
        $db = mysqli_connect("localhost", "root", "", "3ip_2_baza_pracownikow");
        $q = ""
        ?>
    </section>
</body>
</html>

<?php
