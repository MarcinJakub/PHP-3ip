<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>86 - iteracja wylosowanych liczb i znaków</title>
    <link rel="stylesheet" href="styl.css"
</head>
<body>
<header>
    <h1>Zadanie 86 - iteracja wylosowanych liczb i znaków</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>
        Napisz program, który dla podanej liczby całkowitej a losuje a liczb w zakresie <1, 9>.i wyświetla je na ekranie w postaci: liczba i liczba znaków ‘|’.<br><br>

        Przykład a=5<br>
        Wylosowane liczby: 5 3 6 3 1<br>
        5|||||<br>
        3|||<br>
        6||||||<br>
        3|||<br>
        1|<br>

    </p>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
        <label for="a">Podaj a:</label><input type="text" id="a" name="a" />
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['a']) && is_numeric($_POST['a'])){
            $a = $_POST['a'];
            $tab = [];
            for($i = 0; $i < $a; $i++){
                $rand = rand(1,9);
                $tab[$i] = $rand;
            }
        }

        foreach ($tab as $i){
            echo "$i ";
            for($j = 0; $j < $i; $j++){
                echo "| ";
            }
            echo "<br>";
        }
    }
    ?>
</section>
</body>
</html>