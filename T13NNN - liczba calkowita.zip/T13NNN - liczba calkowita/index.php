<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T13NNN - liczba całkowita</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>T13NNN - liczba całkowita</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz przykładową klasę Liczba_Calkowita, która będzie przechowywała wartość całkowitą (prywatną). Klasa ta powinna zawierać metodę wyswietlLiczbe (publiczną), która będzie wyświetlała na ekranie przechowywaną wartość, metodę pobierzliczbe (publiczną) zapisującą podaną w parametrze liczbę całkowitą do pola prywatnego przechowującego liczbę, metodę zwracajLiczbe (publiczną) zwracającą przechowywaną wartość oraz metodę wartość_bezwzgledna (publiczną), zwracającą wartość bezwzględną liczby. Zastosuj klasę w projekcie.</p>
    </header>
    <section>
        <?php
        class Liczba_Calkowita{
            private $liczba;

            function wyswietlLiczbe(){
                echo "Liczba całkowita: ".$this->liczba;
            }

            function pobierzLiczbe($x){
                $this->liczba = $x;
            }

            function zwracajLiczbe(){
                return $this->liczba;
            }

            function wartoscBezwzgledna(){
                return abs($this->liczba);
            }
        }

        $mojaLiczba = new Liczba_Calkowita();
        $mojaLiczba->pobierzLiczbe(-3);
        $mojaLiczba->wyswietlLiczbe();
        echo "<br>";
        $l = $mojaLiczba->zwracajLiczbe();
        echo "$l <br>";
        $bezwzgledna = $mojaLiczba->wartoscBezwzgledna();
        echo "$bezwzgledna";
        ?>
    </section>
</body>
</html>
