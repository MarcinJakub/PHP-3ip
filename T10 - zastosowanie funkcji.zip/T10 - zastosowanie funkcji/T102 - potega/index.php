<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T10 - zastosowanie funkcji</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T10 - zastosowanie funkcji</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>03.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T102</h2>
    <p>Napisz funkcję, której wynikiem będzie podniesienie wartości przekazanego jej poprzez referencję argumentu do potęgi przekazanej również jako argument. Funkcja zwraca wartość i wyświetla wynik w postaci (np. dla wartości 2 i 3):<br><br>

        x = 2<br>
        y = 3<br>
        x<sup>y</sup>=2<sup>3</sup>=8</p>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <label for="x">Podaj x: </label><input type="text" id="x" name="x"/><br>
        <label for="y">Podaj y: </label><input type="text" id="y" name="y"/><br>
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['x'], $_POST['y']) && is_numeric($_POST['x']) && is_numeric($_POST['y'])){
            $x = $_POST['x'];
            $y = $_POST['y'];

            function potega(&$x, $y){
                $wynik = 1;
                for($i = 0; $i < $y; $i++){
                    $wynik *= $x;
                }
                $x = $wynik;
                return $x;
            }

            echo "x = $x<br>y = $y<br>x<sup>y</sup> = $x<sup>$y</sup> = ".potega($x, $y);
        }
    }
    ?>
</section>
</body>
</html>