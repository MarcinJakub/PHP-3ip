<?php
$liczby = file("liczby.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$licznik = 0;
$pierwsza = 0;
foreach($liczby as $x){
    if($x[0] == $x[strlen($x) - 1]){
        if($licznik == 0)
            $pierwsza = $x;
        $licznik++;
    }
}

echo "Jest $licznik takich liczb. Pierwszą z nich jest $pierwsza.";

$plikWynikowy = fopen("wynik_4_1.txt", "w");
fwrite($plikWynikowy, "Jest $licznik takich liczb. Pierwszą z nich jest $pierwsza.");
fclose($plikWynikowy);