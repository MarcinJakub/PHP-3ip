<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T10 - zastosowanie funkcji</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T10 - zastosowanie funkcji</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>09.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T105</h2>
    <p>Napisz funkcję, która dla dwóch liczb całkowitych wyświetla ich wspólny dzielnik (przypomnij sobie algorytm Euklidesa).</p>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <label for="a">Podaj 1. liczbę: </label><input type="number" id="a" name="a"/>
        <label for="b">Podaj 2. liczbę: </label><input type="number" id="b" name="b"/>
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['a'], $_POST['b'])){
            $a = $_POST['a'];
            $b = $_POST['b'];

            function euklides(&$l1, $l2){
                while($l1 != $l2){
                    if($l1 > $l2)
                        $l1 -= $l2;
                    else
                        $l2 -= $l1;
                }
                return $l1;
            }

            echo "Największy wspólny dzielnik dla liczb $a i $b wynosi ".euklides($a, $b);
        }
    }
    ?>
</section>
</body>
</html>