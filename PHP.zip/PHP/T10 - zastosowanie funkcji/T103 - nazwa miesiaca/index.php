<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T10 - zastosowanie funkcji</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T10 - zastosowanie funkcji</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>09.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T103</h2>
    <p>Napisz funkcję, która dla podanej liczby całkowitej w zakresie od 1 do 12 zwraca nazwę miesiąca w języku polskim. W przypadku podania innej wartości zwraca informację o błędzie.</p>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <label for="liczba">Podaj liczbę: </label><input type="text" id="liczba" name="liczba"/>
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['liczba']) && is_numeric($_POST['liczba'])){
            function nazwaMiesiaca($l){
                switch ($l){
                    case 1:
                        return "styczeń";
                    case 2:
                        return "luty";
                    case 3:
                        return "marzec";
                    case 4:
                        return "kwiecień";
                    case 5:
                        return "maj";
                    case 6:
                        return "czerwiec";
                    case 7:
                        return "lipiec";
                    case 8:
                        return "sierpień";
                    case 9:
                        return "wrzesień";
                    case 10:
                        return "październik";
                    case 11:
                        return "listopad";
                    case 12:
                        return "grudzień";
                    default:
                        return "Błąd. Podano nieprawidłową liczbę";
                }
            }
            $miesiac = $_POST['liczba'];
            if($miesiac >= 1 && $miesiac <= 12)
                echo "$miesiac. miesiąc to: <br>".nazwaMiesiaca($miesiac);
            else
                echo nazwaMiesiaca($miesiac);

        }
    }
    ?>
</section>
</body>
</html>