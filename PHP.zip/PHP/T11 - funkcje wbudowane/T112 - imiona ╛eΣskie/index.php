<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T11 - funkcje wbudowane</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T11 - funkcje wbudowane</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>16.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T112</h2>
    <p>Dana jest tablica zawierająca imiona. Napisz funkcję, która wypisuje ilość imion żeńskich zapisanych w tablicy. Dla uproszczenia zakładamy, że imiona żeńskie to te, które kończą się na literę "a". Proszę uwzględnić imiona Kuba i Barnaba.</p>
</header>
<section>
    <?php
    function ileZenskich($t){
        $zenskie = 0;
        foreach($t as $imie){
            if($imie[strlen($imie)-1] == "a" && $imie != "Kuba" && $imie != "Barnaba"){
                $zenskie++;
            }
        }
        return $zenskie;
    }
    $tab = array("Aleksandra","Weronika","Karol","Barnaba","Kuba","Marcin","Danuta");
    echo "Dana jest tablica: ";
    foreach($tab as $x){
        echo "$x ";
    }
    echo "<br><br>W tablicy wystepują ".ileZenskich($tab)." imiona żeńskie.";
    ?>
</section>
</body>
</html>
