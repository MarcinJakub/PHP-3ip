<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T09b - tablica dwuwymiarowa przekatne</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T09b - tablica dwuwymiarowa przekatne</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz program, który do dwuwymiarowej tablicy o wymiarach 3 x 3 wpisuje liczby pseudolosowe z zakresu <0,9>, wyświetla tą tablicę, a następnie oblicza sumę liczb rozmieszczonych wzdłuż przekątnych:

            <ol>
                <li>Przekątna LG_PD - lewy górny i prawy dolny,</li>
                <li>Przekątna LD_PG - lewy dolny i prawy górny.</li>
            </ol>

            Program wyświetla te sumy i odpowiada na pytanie, która z nich jest większa, lub czy są równe.</p>
    </header>
    <section>
        <?php
            $array = array();

            for($i = 0; $i < 3; $i++){
                $array[$i] = [];
                for($j = 0; $j < 3; $j++){
                    $rand = rand(0,9);
                    $array[$i][$j] = $rand;
                }
            }

            for($i = 0; $i < 3; $i++){
                for($j = 0; $j < 3; $j++){
                    echo $array[$i][$j];
                    echo " ";
                }
                echo "<br>";
            }

            $sumaLGPD = $array[0][0] + $array[1][1] + $array[2][2];
            $sumaLDPG = $array[2][0] + $array[1][1] + $array[0][2];

            echo "<br>Suma LG_PD: $sumaLGPD<br>Suma LD_PG: $sumaLDPG<br><br>";

            if($sumaLGPD > $sumaLDPG){
                echo "Większa jest suma <b>LG_PD</b>.";
            } else if($sumaLGPD < $sumaLDPG){
                echo "Większa jest suma <b>LD_PG</b>.";
            } else{
                echo "Obie sumy są równe.";
            }


        ?>
    </section>
</body>
</html>
