<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T09f - losowanie bez powtórzeń</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T09f - losowanie bez powtórzeń</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>
        Napisz program, który do dwuwymiarowej tablicy o wymiarach 7x7 wpisuje pseudolosowe liczby całkowite z zakresu <10,99> i wyświetla tę tablicę z zachowaniem wierszy i kolumn.<br><br>
        Liczby nie mogą się powtarzać.
    </p>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
        <input type="submit" value="Wyślij">
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST") {
        $array = array();
        $array2 = array();
        for ($i = 0; $i <= 89; $i++) {
            $array[$i] = $i + 10;
        }

        for ($i = 0; $i < 7; $i++) {
            $array2[$i] = [];
            for ($j = 0; $j < 7; $j++) {
                $index = rand(0, 89);
                if ($array[$index] != 0) {
                    $array2[$i][$j] = $array[$index];
                    $array[$index] = 0;
                } else {
                    while ($array[$index] == 0) {
                        $index = rand(0, 89);
                    }
                    $array2[$i][$j] = $array[$index];
                    $array[$index] = 0;
                }
            }
        }

        for ($i = 0; $i < 7; $i++) {
            for ($j = 0; $j < 7; $j++) {
                echo $array2[$i][$j];
                echo " ";
            }
            echo "<br>";
        }
    }
    ?>
</section>
</body>
</html>