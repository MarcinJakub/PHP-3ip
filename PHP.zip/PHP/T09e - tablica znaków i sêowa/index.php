<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T09e - tablica znaków i słowa</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T09e - tablica znaków i słowa</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz program w którym do jednowymiarowej tablicy znakowej wpisanych jest 10 znaków podanych przez użytkownika, a następnie:
            <ul>
                <li>pyta użytkownika o długość losowego słowa oraz ilość słów,</li>
                <li>wyświetla wzorcową 10 znakową tablicę,</li>
                <li>wyświetla podaną ilość słów składających się z podanej ilości znaków wygenerowanych ze znaków zapisanych w 10-elementowej tablicy stworzonej na początku programu.</li>
            </ul>
        </p>
    </header>
    <section>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
            <label for="1">Znak 1: </label><input type="text" id="1" name="1" /><br>
            <label for="2">Znak 2: </label><input type="text" id="2" name="2" /><br>
            <label for="3">Znak 3: </label><input type="text" id="3" name="3" /><br>
            <label for="4">Znak 4: </label><input type="text" id="4" name="4" /><br>
            <label for="5">Znak 5: </label><input type="text" id="5" name="5" /><br>
            <label for="6">Znak 6: </label><input type="text" id="6" name="6" /><br>
            <label for="7">Znak 7: </label><input type="text" id="7" name="7" /><br>
            <label for="8">Znak 8: </label><input type="text" id="8" name="8" /><br>
            <label for="9">Znak 9: </label><input type="text" id="9" name="9" /><br>
            <label for="10">Znak 10: </label><input type="text" id="10" name="10" /><br><br>
            <label for="dlugosc">Długość słowa: </label><input type="text" id="dlugosc" name="dlugosc" /><br><br>
            <label for="ilosc">Ilość słów: </label><input type="text" id="ilosc" name="ilosc" /><br><br>
            <input type="submit" value="Wygeneruj słowa">
        </form><br><br>
        <?php
            if(isset($_POST['1'], $_POST['2'], $_POST['3'], $_POST['4'], $_POST['5'], $_POST['6'], $_POST['7'], $_POST['8'], $_POST['9'], $_POST['10'], $_POST['dlugosc'], $_POST['ilosc'])){

                $dlugosc = $_POST['dlugosc'];
                $ilosc = $_POST['ilosc'];

                $array = array($_POST['1'], $_POST['2'], $_POST['3'], $_POST['4'], $_POST['5'], $_POST['6'], $_POST['7'], $_POST['8'], $_POST['9'], $_POST['10']);
                var_dump($array);
                echo "<br><br>";

                for($i = 0; $i < $ilosc; $i++){
                    for($j = 0; $j < $dlugosc; $j++){
                        $rand = rand(1,10);
                        switch($rand){
                            case 1:
                                $rand = $_POST['1'];
                                break;
                            case 2:
                                $rand = $_POST['2'];
                                break;
                            case 3:
                                $rand = $_POST['3'];
                                break;
                            case 4:
                                $rand = $_POST['4'];
                                break;
                            case 5:
                                $rand = $_POST['5'];
                                break;
                            case 6:
                                $rand = $_POST['6'];
                                break;
                            case 7:
                                $rand = $_POST['7'];
                                break;
                            case 8:
                                $rand = $_POST['8'];
                                break;
                            case 9:
                                $rand = $_POST['9'];
                                break;
                            case 10:
                                $rand = $_POST['10'];
                                break;
                        }
                        echo $rand;
                    }
                    echo " ";
                }
            }
        ?>
    </section>
</body>
</html>
