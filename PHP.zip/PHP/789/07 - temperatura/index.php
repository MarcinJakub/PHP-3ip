<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie 07 - temperatura</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header>
        <h1>Zadanie 07 - temperatura</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz program, który dla podanej temperatury w stopniach Celsjusza zamienia ją na stopnie Kelwina i Fahrenheita.</p>
    </header>
    <section>
        <form method="post">
            <label for="celcius">Podaj temperaturę w <sup>o</sup>C</label>
            <input type="text" id="celcius" name="celcius" />
            <input type="submit" value="Wyślij" />
        </form>
        <?php
        if(isset($_POST['celcius']) && is_numeric($_POST['celcius'])) {
            $celcius = (float)$_POST['celcius'];
            $fahrenheit = $celcius * 1.8 + 32;
            $kelvin = $celcius + 273.15;

            echo "Wyniki obliczeń dla T<sub>Celcjusz</sub> = $celcius<br>
                  T<sub>Kelvin</sub> = $kelvin<br>
                  T<sub>Fahrenheit</sub> = $fahrenheit";
        }
        ?>
    </section>
</body>
</html>
