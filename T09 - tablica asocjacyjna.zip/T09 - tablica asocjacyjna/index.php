<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T09 - tablica asocjacyjna</title>
    <link rel="stylesheet" href="styl.css"
</head>
<body>
    <header>
        <h1>Zadanie T09 - tablica asocjacyjna</h1>
        <h2>Autor: Marcin Panter</h2>
        <p>Po zapoznaniu się  z materiałem napisz skrypt, w którym zdefiniuj tablicę asocjacyjną - 5-elementową. W tablicy indeksami są nazwy państw, a wartościami ich stolice.</p>
    </header>
    <section>
        <?php
            $array = array(
                'Polska' => 'Warszawa',
                'Niemcy' => 'Berlin',
                'Stany Zjednoczone' => 'Waszyngton',
                'Japonia' => 'Tokio',
                'Wielka Brytania' => 'Londyn'
            );

            var_dump($array);
        ?>
    </section>
</body>
</html>