<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T17 - zastosowanie biblioteki PDO</title>
</head>
<body>
    <header>
        <h1>T17 - zastosowanie biblioteki PDO</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
    </header>
    <section>
        <form action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
            <h3>Rejestracja klienta</h3>
            <label for="nazwisko">Nazwisko: </label><br><input type="text" id="nazwisko" name="nazwisko" /><br>
            <label for="imie">Imię: </label><br><input type="text" id="imie" name="imie" /><br><br>
            <input type="submit" value="Wyślij">
            <input type="reset" value="wyczyść" />
        </form>
        <?php
        $dsn = "mysql:host=localhost;dbname=3ip2_biblioteka";
        $imie = $_POST['imie'];
        $nazwisko = $_POST['nazwisko'];

        try {
            $pdo = new PDO($dsn, "root", "");
            echo 'Połączenie nawiązane!';
            $q = $pdo->exec('INSERT INTO autorzy (imie, nazwisko) VALUES ($imie, $nazwisko)');
        } catch (PDOException $e) {
            echo 'Błąd połączenia: ' . $e->getMessage();
            exit;
        }
        ?>
    </section>
</body>
</html>