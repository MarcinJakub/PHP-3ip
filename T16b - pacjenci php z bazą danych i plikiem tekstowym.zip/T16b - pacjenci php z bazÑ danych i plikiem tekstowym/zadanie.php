<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T16b - pacjenci z bazą danych i plikiem tekstowym</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>T16b - pacjenci z bazą danych i plikiem tekstowym</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <ol>
            <li>Utwórz bazę danych o nazwie 3pir_2_pacjenci.</li>
            <li>W bazie danych utwórz tabelę tabela_1 zawierającą kolumny:
                <ul>
                    <li>identyfikator,</li>
                    <li>imię,</li>
                    <li>nazwisko,</li>
                    <li>email.</li>
                </ul>
            </li>
            <li>Utwórz plik tekstowy o nazwie dane.txt zawierający dane 3 pacjentów.</li>
            <li>Napisz skrypt php, który czyta dane z pliku i zapisuje je do tabeli tabela_1 i wyświetla je na stronie zadanie.php w postaci tabeli.</li>
        </ol>
        <p>Rozwiązanie powinno zawierać: eksport bazy, plik z danymi oraz skrypt php. </p>
    </header>
    <section>
        <form action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
            <button type="submit" name="zaladuj_dane">Załaduj dane</button>
            <button type="submit" name="wypisz_dane">Wypisz dane</button>
        </form>
        <?php
        $db = mysqli_connect("localhost", "root", "", "3pir_2_pacjenci");
        mysqli_set_charset($db, "utf8");
        function zaladujDane(){
            global $db;
            $dane = file("dane.txt");

            foreach($dane as $linia){
                $linia = trim($linia);
                list($imie, $nazwisko, $email) = explode(" ", $linia);

                $imie = mb_convert_encoding($imie, 'UTF-8', 'ISO-8859-2');
                $nazwisko = mb_convert_encoding($nazwisko, 'UTF-8', 'ISO-8859-2');

                $q = "INSERT INTO tabela_1 (imie, nazwisko, email) VALUES ('$imie', '$nazwisko', '$email')";
                mysqli_query($db, $q);
            }
        }

        function wypiszDane(){
            global $db;
            $q = "SELECT * FROM tabela_1";
            $wynik = mysqli_query($db, $q);

            if(mysqli_num_rows($wynik) > 0){
                echo "<table>
                      <tr>
                        <th>ID</th>
                        <th>Imię</th>
                        <th>Nazwisko</th>
                        <th>Email</th>
                      </tr>";
                while($row = mysqli_fetch_assoc($wynik)){
                    echo "<tr>
                              <td>" . $row["identyfikator"] . "</td>
                              <td>" . $row["imie"] . "</td>
                              <td>" . $row["nazwisko"] . "</td>
                              <td>" . $row["email"] . "</td>
                          </tr>";
                }
            } else{
                echo "Brak danych do wyświetlenia";
            }
        }

        if(isset($_POST['zaladuj_dane'])){
            zaladujDane();
        }
        if(isset($_POST['wypisz_dane'])){
            wypiszDane();
        }

        ?>
    </section>
</body>
</html>