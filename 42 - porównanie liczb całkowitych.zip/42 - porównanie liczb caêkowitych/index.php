<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>42 - porównanie liczb całkowitych</title>
    <link rel="stylesheet" href="styl.css"
</head>
<body>
    <header>
        <h1>Zadanie 42  - porównanie liczb całkowitych</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>
            Dane są dwie różne liczby całkowite.<br>
            Napisz program który:<br>
            sprawdza czy podane dwie liczby całkowite są parzyste i tylko w tym przypadku wypisuje większą z nich. W przypadku podania liczby nieparzystej wypisuje która to liczba lub liczby.<br><br>
            Wejście<br>
            Na wejściu dwie różne liczby całkowite.<br><br>
            Wyjście<br>
            Na wyjściu większa z nich jeśli obie są parzyste lub ta liczba lub liczby jeśli są nieparzyste.<br><br>
            Przykład 1<br>
            4 8<br>
            8<br><br>
            Przykład 2<br>
            3 4<br>
            3<br><br>
            Przykład 3<br>
            1 7<br>
            1
        </p>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
            <label for="a">Podaj liczbę a: = </label><input type="text" id="a" name="a">
            <label for="b">Podaj liczbę b: = </label><input type="text" id="b" name="b">
            <input type="submit" value="Wyślij" />
        </form>
    </header>
    <section>
        <?php
        if($_SERVER['REQUEST_METHOD']=="POST"){
            if(isset($_POST['a'],$_POST['b']) && is_numeric($_POST['a'] ) && is_numeric($_POST['b'])){
                $a = $_POST['a'];
                $b = $_POST['b'];


                if($a % 2 == 0 && $b % 2 == 0){
                    if($a > $b){
                        echo "Liczba a: $a jest większa";
                    }
                    elseif($a < $b){
                        echo "Liczba b: $b jest większa";
                    }
                    else{
                        echo "Liczby są równe";
                    }
                }
                else {
                    if($a % 2 != 0){
                        echo "Liczba a: $a jest nieparzysta<br>";
                    }
                    if($b % 2 != 0){
                        echo "Liczba b: $b jest nieparzysta";
                    }
                }
            }
        }
        ?>
    </section>
</body>
</html>