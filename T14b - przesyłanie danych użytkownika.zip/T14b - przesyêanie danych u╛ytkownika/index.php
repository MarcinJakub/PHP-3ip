<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>T14b - przesyłanie danyhc użytkownika</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>T14b - przesyłanie danych użytkownika</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <h3>Podstawowa wersja rozwiązania</h3>
        <p>Utwórz skrypt, który dane użytkownika przesyłane za pomocą formularza będzie przekazywał do utworzonego pliku cookie. Formularz powinien zawierać imię i nazwisko użytkownika.</p><br>
        <h3>Wersja rozszerzona</h3>
        <p>Dodatkowo przekazana jest również data urodzin użytkownika. Skrypt powinien wyświetlać informację, za ile dni użytkownik będzie obchodził urodziny.</p>
    </header>
    <section>
        <form action <?php echo $_SERVER['PHP_SELF']?> method="post">
            <label for="firstName">Podaj imię: </label><input type="text" id="firstName" name="firstName">
            <label for="surname">Podaj nazwisko: </label><input type="text" id="surname" name="surname">
            <label for="birthday">Podaj datę urodzin: </label><input type="date" id="birthday" name="birthday">
            <input type="submit" value="Wyślij">
        </form>
        <?php
        if(isset($_POST['firstName'], $_POST['surname'], $_POST['birthday'])){
            setcookie("imie", $_POST['firstName'], time() + 3600);
            setcookie("nazwisko" , $_POST['surname'], time() + 3600);
            setcookie("urodziny", $_POST['birthday'], time() + 3600);

            if(isset($_COOKIE['urodziny'])){
                $birthday = $_COOKIE['urodziny'];
                $today = date("m-d");
                echo "Urodziłeś się ".$birthday;
            }
        }
        ?>
    </section>
</body>
</html>