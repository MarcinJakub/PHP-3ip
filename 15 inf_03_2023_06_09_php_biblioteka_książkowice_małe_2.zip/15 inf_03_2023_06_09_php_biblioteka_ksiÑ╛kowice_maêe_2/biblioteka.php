<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biblioteka</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <section id="baner">
        <h1>Biblioteka w Książkowicach Małych</h1>
    </section>
    <section id="lewy">
        <h4>Dodaj czytelnika</h4>
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
            <label for="imie">Imię: </label><input type="text" id="imie" name="imie"/><br>
            <label for="nazwisko">Nazwisko: </label><input type="text" id="nazwisko" name="nazwisko"/><br>
            <label for="symbol">Symbol: </label><input type="number" id="symbol" name="symbol"/><br>
            <input type="submit" value="AKCEPTUJ">
        </form>
        <?php
        if(isset($_POST['imie'], $_POST['nazwisko'], $_POST['symbol'])){
            $imie = $_POST['imie'];
            $nazwisko = $_POST['nazwisko'];
            $symbol = $_POST['symbol'];

            echo "<p>Dodano czytelnika $imie $nazwisko</p>";

            $db = mysqli_connect('localhost', 'root', '', 'biblioteka');
            mysqli_set_charset($db, 'utf8');
            $q = 'INSERT INTO czytelnicy (imie, nazwisko, kod) VALUES ('.$imie.','.$nazwisko.','.$symbol.')';
        }
        ?>
    </section>
    <section id="srodkowy">
        <img src="biblioteka.png" alt="biblioteka"/>
        <h6>ul. Czytelników 15;<br>Książkowice Małe</h6>
        <p><a href="mailto:biuro@bib.pl">Czy masz jakieś uwagi?</a></p>
    </section>
    <section id="prawy">
        <h4>Nasi czytelnicy:</h4>
        <?php
        $db = mysqli_connect('localhost', 'root', '', 'biblioteka');
        mysqli_set_charset($db, 'utf8');
        $q = 'SELECT imie, nazwisko FROM czytelnicy ORDER BY nazwisko ASC';
        $wynik = mysqli_query($db, $q);

        /*while(mysqli_fetch_assoc($wynik)){

        }*/
        ?>
    </section>
    <section id="stopka">
        <p>Projekt witryny: Marcin Panter</p>
    </section>
</body>
</html>