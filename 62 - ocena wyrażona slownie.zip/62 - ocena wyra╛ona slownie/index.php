<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>62 - ocena wyrażona słownie</title>
    <link rel="stylesheet" href="styl.css"
</head>
<body>
<header>
    <h1>Zadanie 62  - ocena wyrażona słownie</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>
        Napisz program, który dla podanej wartości wyświetla ocenę wyrażoną słownie według następującego klucza:<br>
        0 – nieklasyfikowany<br>
        1,2,3 – poprawny<br>
        4,5 – dobry<br>
        6 – wyróżniający.<br>
        Na pozostałe wartości reaguje wyświetleniem komunikatu: „niewłaściwa liczba”.<br>
    </p>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
        <label for="ocena">Podaj liczbę całkowitą: </label><input type="text" id="ocena" name="ocena"/>
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['ocena']) && is_numeric($_POST['ocena'])){
            $ocena = floor($_POST['ocena']);
            $nazwa = "";

            switch($ocena){
                case 0:
                    $nazwa = "nieklasyfikowany";
                    break;
                case 1:
                    $nazwa = "poprawny";
                    break;
                case 2:
                    $nazwa = "poprawny";
                    break;
                case 3:
                    $nazwa = "poprawny";
                    break;
                case 4:
                    $nazwa = "dobry";
                    break;
                case 5:
                    $nazwa = "dobry";
                    break;
                case 6:
                    $nazwa = "wyróżniający";
            }

            if($ocena >= 0 && $ocena < 7){
                echo "Podana liczba to: <b>$ocena</b><br>";
                echo "Nazwa oceny: <b>$nazwa</b>";
            } else{
                echo "Podana liczba to: <b>$ocena</b><br>";
                echo "Nazwa oceny: <b>Niewłaściwa liczba</b>";
            }
        }
    }
    ?>
</section>
</body>
</html>